-- CreateTable
CREATE TABLE "healing_patterns" (
    "id" TEXT NOT NULL,
    "diagnosisType" "DiagnosisType" NOT NULL,
    "errorType" TEXT,
    "culprit" TEXT,
    "errorPattern" TEXT NOT NULL,
    "commands" TEXT[],
    "description" TEXT NOT NULL,
    "successCount" INTEGER NOT NULL DEFAULT 0,
    "failureCount" INTEGER NOT NULL DEFAULT 0,
    "confidence" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    "autoApproved" BOOLEAN NOT NULL DEFAULT false,
    "requiresBackup" BOOLEAN NOT NULL DEFAULT true,
    "createdBy" TEXT,
    "lastSuccessAt" TIMESTAMP(3),
    "lastFailureAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "lastUsedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "healing_patterns_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "healing_patterns_diagnosisType_errorType_idx" ON "healing_patterns"("diagnosisType", "errorType");

-- CreateIndex
CREATE INDEX "healing_patterns_confidence_idx" ON "healing_patterns"("confidence");

-- CreateIndex
CREATE INDEX "healing_patterns_autoApproved_idx" ON "healing_patterns"("autoApproved");
