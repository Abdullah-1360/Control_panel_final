-- CreateTable
CREATE TABLE "servers" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "environment" VARCHAR(20),
    "tags" TEXT[],
    "notes" VARCHAR(1000),
    "platformType" VARCHAR(20) NOT NULL,
    "host" VARCHAR(255) NOT NULL,
    "port" INTEGER NOT NULL,
    "connectionProtocol" VARCHAR(20) NOT NULL,
    "username" VARCHAR(100) NOT NULL,
    "authType" VARCHAR(50) NOT NULL,
    "encryptedPrivateKey" TEXT,
    "encryptedPassphrase" TEXT,
    "encryptedPassword" TEXT,
    "privilegeMode" VARCHAR(20) NOT NULL,
    "sudoMode" VARCHAR(30) NOT NULL,
    "encryptedSudoPassword" TEXT,
    "hostKeyStrategy" VARCHAR(30) NOT NULL,
    "knownHostFingerprints" JSONB,
    "lastTestStatus" VARCHAR(20),
    "lastTestAt" TIMESTAMP(3),
    "lastTestResult" JSONB,
    "createdByUserId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "servers_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "servers_name_key" ON "servers"("name");

-- CreateIndex
CREATE INDEX "servers_name_idx" ON "servers"("name");

-- CreateIndex
CREATE INDEX "servers_host_idx" ON "servers"("host");

-- CreateIndex
CREATE INDEX "servers_platformType_idx" ON "servers"("platformType");

-- CreateIndex
CREATE INDEX "servers_environment_idx" ON "servers"("environment");

-- CreateIndex
CREATE INDEX "servers_lastTestStatus_idx" ON "servers"("lastTestStatus");

-- CreateIndex
CREATE INDEX "servers_deletedAt_idx" ON "servers"("deletedAt");

-- CreateIndex
CREATE INDEX "servers_createdByUserId_idx" ON "servers"("createdByUserId");

-- AddForeignKey
ALTER TABLE "servers" ADD CONSTRAINT "servers_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
