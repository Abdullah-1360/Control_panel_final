-- CreateEnum
CREATE TYPE "AssetType" AS ENUM ('SITE_WORDPRESS', 'SITE_GENERIC', 'DOMAIN', 'SSL_CERT', 'DATABASE_MYSQL', 'DATABASE_POSTGRES');

-- CreateEnum
CREATE TYPE "AssetStatus" AS ENUM ('PENDING', 'ACTIVE', 'WARNING', 'ERROR', 'SUSPENDED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "AssetHealth" AS ENUM ('UNKNOWN', 'HEALTHY', 'DEGRADED', 'DOWN');

-- CreateEnum
CREATE TYPE "DiscoverySource" AS ENUM ('MANUAL', 'WHM_SYNC', 'SSH_SCAN', 'INTEGRATION_SYNC');

-- CreateEnum
CREATE TYPE "RelationType" AS ENUM ('HOSTS', 'PROTECTS', 'USES', 'POINTS_TO', 'DEPENDS_ON');

-- CreateTable
CREATE TABLE "assets" (
    "id" TEXT NOT NULL,
    "type" "AssetType" NOT NULL,
    "identifier" TEXT NOT NULL,
    "friendlyName" TEXT,
    "serverId" TEXT,
    "integrationId" TEXT,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "encryptedSecrets" TEXT,
    "status" "AssetStatus" NOT NULL DEFAULT 'PENDING',
    "health" "AssetHealth" NOT NULL DEFAULT 'UNKNOWN',
    "discoverySource" "DiscoverySource" NOT NULL DEFAULT 'MANUAL',
    "lastScannedAt" TIMESTAMP(3),
    "lastHealthCheckAt" TIMESTAMP(3),
    "nextScanAt" TIMESTAMP(3),
    "tags" TEXT[],
    "notes" TEXT,
    "createdByUserId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "assets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "asset_relations" (
    "id" TEXT NOT NULL,
    "parentId" TEXT NOT NULL,
    "childId" TEXT NOT NULL,
    "relationType" "RelationType" NOT NULL,
    "metadata" JSONB DEFAULT '{}',
    "createdByUserId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "asset_relations_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "assets_type_idx" ON "assets"("type");

-- CreateIndex
CREATE INDEX "assets_status_idx" ON "assets"("status");

-- CreateIndex
CREATE INDEX "assets_health_idx" ON "assets"("health");

-- CreateIndex
CREATE INDEX "assets_serverId_idx" ON "assets"("serverId");

-- CreateIndex
CREATE INDEX "assets_integrationId_idx" ON "assets"("integrationId");

-- CreateIndex
CREATE INDEX "assets_identifier_idx" ON "assets"("identifier");

-- CreateIndex
CREATE INDEX "assets_discoverySource_idx" ON "assets"("discoverySource");

-- CreateIndex
CREATE INDEX "assets_deletedAt_idx" ON "assets"("deletedAt");

-- CreateIndex
CREATE INDEX "assets_createdByUserId_idx" ON "assets"("createdByUserId");

-- CreateIndex
CREATE INDEX "asset_relations_parentId_idx" ON "asset_relations"("parentId");

-- CreateIndex
CREATE INDEX "asset_relations_childId_idx" ON "asset_relations"("childId");

-- CreateIndex
CREATE INDEX "asset_relations_relationType_idx" ON "asset_relations"("relationType");

-- CreateIndex
CREATE UNIQUE INDEX "asset_relations_parentId_childId_relationType_key" ON "asset_relations"("parentId", "childId", "relationType");

-- AddForeignKey
ALTER TABLE "assets" ADD CONSTRAINT "assets_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES "servers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "assets" ADD CONSTRAINT "assets_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES "integrations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "assets" ADD CONSTRAINT "assets_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "asset_relations" ADD CONSTRAINT "asset_relations_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "assets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "asset_relations" ADD CONSTRAINT "asset_relations_childId_fkey" FOREIGN KEY ("childId") REFERENCES "assets"("id") ON DELETE CASCADE ON UPDATE CASCADE;
