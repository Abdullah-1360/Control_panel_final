-- CreateEnum
CREATE TYPE "NotificationTrigger" AS ENUM ('USER_CREATED', 'USER_UPDATED', 'USER_DELETED', 'USER_ACTIVATED', 'USER_DEACTIVATED', 'USER_ROLE_CHANGED', 'USER_LOCKED', 'USER_UNLOCKED', 'USER_LOGIN', 'USER_LOGOUT', 'PASSWORD_CHANGED', 'PASSWORD_RESET_REQUESTED', 'MFA_ENABLED', 'MFA_DISABLED', 'FAILED_LOGIN_ATTEMPT', 'SESSION_CREATED', 'SESSION_REVOKED', 'SETTINGS_CHANGED');

-- CreateEnum
CREATE TYPE "RecipientType" AS ENUM ('SPECIFIC_USER', 'SPECIFIC_ROLE', 'AFFECTED_USER', 'ALL_USERS', 'CUSTOM_EMAIL', 'HYBRID');

-- CreateEnum
CREATE TYPE "EmailStatus" AS ENUM ('PENDING', 'SENT', 'FAILED');

-- CreateEnum
CREATE TYPE "DeliveryStatus" AS ENUM ('DELIVERED', 'OPENED', 'CLICKED', 'BOUNCED');

-- CreateTable
CREATE TABLE "notification_rules" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "trigger" "NotificationTrigger" NOT NULL,
    "templateKey" TEXT NOT NULL,
    "recipientType" "RecipientType" NOT NULL,
    "recipientValue" JSONB NOT NULL,
    "conditions" JSONB,
    "priority" INTEGER NOT NULL DEFAULT 5,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdBy" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "notification_rules_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "email_history" (
    "id" TEXT NOT NULL,
    "ruleId" TEXT,
    "templateKey" TEXT NOT NULL,
    "recipients" TEXT[],
    "subject" TEXT NOT NULL,
    "htmlBody" TEXT NOT NULL,
    "textBody" TEXT NOT NULL,
    "variables" JSONB NOT NULL,
    "status" "EmailStatus" NOT NULL,
    "sentAt" TIMESTAMP(3),
    "failedAt" TIMESTAMP(3),
    "error" TEXT,
    "deliveryStatus" "DeliveryStatus",
    "triggeredBy" TEXT NOT NULL,
    "triggerEvent" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "email_history_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "notification_rules_trigger_idx" ON "notification_rules"("trigger");

-- CreateIndex
CREATE INDEX "notification_rules_isActive_idx" ON "notification_rules"("isActive");

-- CreateIndex
CREATE INDEX "notification_rules_priority_idx" ON "notification_rules"("priority");

-- CreateIndex
CREATE INDEX "email_history_ruleId_idx" ON "email_history"("ruleId");

-- CreateIndex
CREATE INDEX "email_history_status_idx" ON "email_history"("status");

-- CreateIndex
CREATE INDEX "email_history_triggeredBy_idx" ON "email_history"("triggeredBy");

-- CreateIndex
CREATE INDEX "email_history_triggerEvent_idx" ON "email_history"("triggerEvent");

-- CreateIndex
CREATE INDEX "email_history_createdAt_idx" ON "email_history"("createdAt");

-- AddForeignKey
ALTER TABLE "email_history" ADD CONSTRAINT "email_history_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES "notification_rules"("id") ON DELETE SET NULL ON UPDATE CASCADE;
