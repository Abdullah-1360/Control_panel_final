-- AlterTable
ALTER TABLE "servers" ADD COLUMN     "alertCpuThreshold" DOUBLE PRECISION NOT NULL DEFAULT 90.0,
ADD COLUMN     "alertDiskThreshold" DOUBLE PRECISION NOT NULL DEFAULT 90.0,
ADD COLUMN     "alertRamThreshold" DOUBLE PRECISION NOT NULL DEFAULT 95.0,
ADD COLUMN     "metricsEnabled" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "metricsInterval" INTEGER NOT NULL DEFAULT 900;

-- CreateTable
CREATE TABLE "server_metrics" (
    "id" TEXT NOT NULL,
    "serverId" TEXT NOT NULL,
    "cpuUsagePercent" DOUBLE PRECISION NOT NULL,
    "cpuCores" INTEGER,
    "loadAverage1m" DOUBLE PRECISION,
    "loadAverage5m" DOUBLE PRECISION,
    "loadAverage15m" DOUBLE PRECISION,
    "memoryTotalMB" INTEGER NOT NULL,
    "memoryUsedMB" INTEGER NOT NULL,
    "memoryFreeMB" INTEGER NOT NULL,
    "memoryAvailableMB" INTEGER,
    "memoryUsagePercent" DOUBLE PRECISION NOT NULL,
    "swapTotalMB" INTEGER,
    "swapUsedMB" INTEGER,
    "swapUsagePercent" DOUBLE PRECISION,
    "diskTotalGB" DOUBLE PRECISION NOT NULL,
    "diskUsedGB" DOUBLE PRECISION NOT NULL,
    "diskFreeGB" DOUBLE PRECISION NOT NULL,
    "diskUsagePercent" DOUBLE PRECISION NOT NULL,
    "diskReadMBps" DOUBLE PRECISION,
    "diskWriteMBps" DOUBLE PRECISION,
    "diskIops" INTEGER,
    "networkRxMBps" DOUBLE PRECISION,
    "networkTxMBps" DOUBLE PRECISION,
    "networkRxTotalMB" DOUBLE PRECISION,
    "networkTxTotalMB" DOUBLE PRECISION,
    "uptime" INTEGER NOT NULL,
    "processCount" INTEGER,
    "threadCount" INTEGER,
    "detectedOS" TEXT,
    "kernelVersion" TEXT,
    "collectionLatency" INTEGER NOT NULL,
    "collectionSuccess" BOOLEAN NOT NULL DEFAULT true,
    "collectionError" TEXT,
    "collectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "server_metrics_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "server_metrics_serverId_collectedAt_idx" ON "server_metrics"("serverId", "collectedAt");

-- CreateIndex
CREATE INDEX "server_metrics_collectedAt_idx" ON "server_metrics"("collectedAt");

-- CreateIndex
CREATE INDEX "servers_metricsEnabled_idx" ON "servers"("metricsEnabled");

-- AddForeignKey
ALTER TABLE "server_metrics" ADD CONSTRAINT "server_metrics_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES "servers"("id") ON DELETE CASCADE ON UPDATE CASCADE;
