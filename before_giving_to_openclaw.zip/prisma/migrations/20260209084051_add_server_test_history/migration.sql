-- CreateTable
CREATE TABLE "server_test_history" (
    "id" TEXT NOT NULL,
    "serverId" TEXT NOT NULL,
    "triggeredByUserId" TEXT NOT NULL,
    "success" BOOLEAN NOT NULL,
    "message" TEXT NOT NULL,
    "latency" INTEGER NOT NULL,
    "details" JSONB NOT NULL,
    "detectedOS" TEXT,
    "detectedUsername" TEXT,
    "errors" TEXT[],
    "warnings" TEXT[],
    "testedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "server_test_history_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "server_test_history_serverId_idx" ON "server_test_history"("serverId");

-- CreateIndex
CREATE INDEX "server_test_history_triggeredByUserId_idx" ON "server_test_history"("triggeredByUserId");

-- CreateIndex
CREATE INDEX "server_test_history_testedAt_idx" ON "server_test_history"("testedAt");

-- AddForeignKey
ALTER TABLE "server_test_history" ADD CONSTRAINT "server_test_history_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES "servers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "server_test_history" ADD CONSTRAINT "server_test_history_triggeredByUserId_fkey" FOREIGN KEY ("triggeredByUserId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
