/*
  Warnings:

  - You are about to drop the `asset_relations` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `assets` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "HealingMode" AS ENUM ('MANUAL', 'SEMI_AUTO', 'FULL_AUTO');

-- CreateEnum
CREATE TYPE "HealerTrigger" AS ENUM ('MANUAL', 'SEMI_AUTO', 'FULL_AUTO', 'SEARCH');

-- CreateEnum
CREATE TYPE "DiagnosisType" AS ENUM ('WSOD', 'DB_ERROR', 'MAINTENANCE', 'INTEGRITY', 'PERMISSION', 'CACHE', 'PLUGIN_CONFLICT', 'THEME_CONFLICT', 'MEMORY_EXHAUSTION', 'SYNTAX_ERROR', 'HEALTHY', 'UNKNOWN');

-- CreateEnum
CREATE TYPE "HealerStatus" AS ENUM ('PENDING', 'ANALYZING', 'DIAGNOSED', 'APPROVED', 'HEALING', 'VERIFYING', 'SUCCESS', 'FAILED', 'SKIPPED', 'ROLLED_BACK');

-- CreateEnum
CREATE TYPE "BackupType" AS ENUM ('FILE', 'DATABASE', 'FULL');

-- CreateEnum
CREATE TYPE "BackupStatus" AS ENUM ('PENDING', 'COMPLETED', 'FAILED', 'EXPIRED');

-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "HealthStatus" ADD VALUE 'MAINTENANCE';
ALTER TYPE "HealthStatus" ADD VALUE 'HEALING';

-- DropForeignKey
ALTER TABLE "asset_relations" DROP CONSTRAINT "asset_relations_childId_fkey";

-- DropForeignKey
ALTER TABLE "asset_relations" DROP CONSTRAINT "asset_relations_parentId_fkey";

-- DropForeignKey
ALTER TABLE "assets" DROP CONSTRAINT "assets_createdByUserId_fkey";

-- DropForeignKey
ALTER TABLE "assets" DROP CONSTRAINT "assets_integrationId_fkey";

-- DropForeignKey
ALTER TABLE "assets" DROP CONSTRAINT "assets_serverId_fkey";

-- DropTable
DROP TABLE "asset_relations";

-- DropTable
DROP TABLE "assets";

-- DropEnum
DROP TYPE "AssetHealth";

-- DropEnum
DROP TYPE "AssetStatus";

-- DropEnum
DROP TYPE "AssetType";

-- DropEnum
DROP TYPE "DiscoverySource";

-- DropEnum
DROP TYPE "RelationType";

-- CreateTable
CREATE TABLE "wp_sites" (
    "id" TEXT NOT NULL,
    "serverId" TEXT NOT NULL,
    "domain" TEXT NOT NULL,
    "path" TEXT NOT NULL,
    "cPanelUsername" TEXT,
    "wpVersion" TEXT,
    "phpVersion" TEXT,
    "dbName" TEXT,
    "dbHost" TEXT DEFAULT 'localhost',
    "healingMode" "HealingMode" NOT NULL DEFAULT 'MANUAL',
    "isHealerEnabled" BOOLEAN NOT NULL DEFAULT false,
    "maxHealingAttempts" INTEGER NOT NULL DEFAULT 3,
    "healingCooldown" INTEGER NOT NULL DEFAULT 1800,
    "blacklistedPlugins" TEXT[] DEFAULT ARRAY['woocommerce', 'woocommerce-*']::TEXT[],
    "blacklistedThemes" TEXT[],
    "healthStatus" "HealthStatus" NOT NULL DEFAULT 'UNKNOWN',
    "lastHealthCheck" TIMESTAMP(3),
    "healthScore" INTEGER,
    "lastError" TEXT,
    "lastHealedAt" TIMESTAMP(3),
    "healingAttempts" INTEGER NOT NULL DEFAULT 0,
    "lastDiagnosedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "wp_sites_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "healer_executions" (
    "id" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "trigger" "HealerTrigger" NOT NULL,
    "triggeredBy" TEXT,
    "diagnosisType" "DiagnosisType" NOT NULL,
    "diagnosisDetails" TEXT NOT NULL,
    "confidence" DOUBLE PRECISION NOT NULL,
    "logsAnalyzed" TEXT NOT NULL,
    "suggestedAction" TEXT NOT NULL,
    "suggestedCommands" TEXT NOT NULL,
    "actionTaken" TEXT,
    "backupId" TEXT,
    "status" "HealerStatus" NOT NULL,
    "errorMessage" TEXT,
    "executionLogs" TEXT NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "diagnosedAt" TIMESTAMP(3),
    "approvedAt" TIMESTAMP(3),
    "healedAt" TIMESTAMP(3),
    "verifiedAt" TIMESTAMP(3),
    "finishedAt" TIMESTAMP(3),
    "duration" INTEGER,
    "preHealthScore" INTEGER,
    "postHealthScore" INTEGER,
    "wasSuccessful" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "healer_executions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "healer_backups" (
    "id" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "backupType" "BackupType" NOT NULL,
    "filePath" TEXT NOT NULL,
    "fileSize" INTEGER,
    "backupData" TEXT NOT NULL,
    "status" "BackupStatus" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "healer_backups_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "wp_sites_domain_key" ON "wp_sites"("domain");

-- CreateIndex
CREATE INDEX "wp_sites_serverId_idx" ON "wp_sites"("serverId");

-- CreateIndex
CREATE INDEX "wp_sites_healthStatus_idx" ON "wp_sites"("healthStatus");

-- CreateIndex
CREATE INDEX "wp_sites_isHealerEnabled_idx" ON "wp_sites"("isHealerEnabled");

-- CreateIndex
CREATE INDEX "wp_sites_domain_idx" ON "wp_sites"("domain");

-- CreateIndex
CREATE INDEX "healer_executions_siteId_idx" ON "healer_executions"("siteId");

-- CreateIndex
CREATE INDEX "healer_executions_status_idx" ON "healer_executions"("status");

-- CreateIndex
CREATE INDEX "healer_executions_trigger_idx" ON "healer_executions"("trigger");

-- CreateIndex
CREATE INDEX "healer_executions_diagnosisType_idx" ON "healer_executions"("diagnosisType");

-- CreateIndex
CREATE INDEX "healer_executions_startedAt_idx" ON "healer_executions"("startedAt");

-- CreateIndex
CREATE INDEX "healer_backups_siteId_idx" ON "healer_backups"("siteId");

-- CreateIndex
CREATE INDEX "healer_backups_status_idx" ON "healer_backups"("status");

-- CreateIndex
CREATE INDEX "healer_backups_expiresAt_idx" ON "healer_backups"("expiresAt");

-- AddForeignKey
ALTER TABLE "wp_sites" ADD CONSTRAINT "wp_sites_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES "servers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "healer_executions" ADD CONSTRAINT "healer_executions_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "wp_sites"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "healer_executions" ADD CONSTRAINT "healer_executions_backupId_fkey" FOREIGN KEY ("backupId") REFERENCES "healer_backups"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "healer_backups" ADD CONSTRAINT "healer_backups_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "wp_sites"("id") ON DELETE CASCADE ON UPDATE CASCADE;
