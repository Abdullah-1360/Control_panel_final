-- AlterTable
ALTER TABLE "wp_sites" ALTER COLUMN "healingCooldown" SET DEFAULT 60;
