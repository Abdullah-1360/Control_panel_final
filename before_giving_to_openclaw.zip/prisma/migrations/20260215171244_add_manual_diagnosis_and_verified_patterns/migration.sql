-- AlterTable
ALTER TABLE "healing_patterns" ADD COLUMN     "commandSequence" TEXT[] DEFAULT ARRAY[]::TEXT[],
ADD COLUMN     "verified" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "verifiedAt" TIMESTAMP(3),
ADD COLUMN     "verifiedBy" TEXT;

-- CreateTable
CREATE TABLE "manual_diagnosis_sessions" (
    "id" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "commands" JSONB NOT NULL DEFAULT '[]',
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "findings" JSONB,
    "learnedPatternId" TEXT,
    "startedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "manual_diagnosis_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "manual_diagnosis_sessions_siteId_idx" ON "manual_diagnosis_sessions"("siteId");

-- CreateIndex
CREATE INDEX "manual_diagnosis_sessions_status_idx" ON "manual_diagnosis_sessions"("status");

-- CreateIndex
CREATE INDEX "healing_patterns_verified_idx" ON "healing_patterns"("verified");

-- AddForeignKey
ALTER TABLE "manual_diagnosis_sessions" ADD CONSTRAINT "manual_diagnosis_sessions_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "wp_sites"("id") ON DELETE CASCADE ON UPDATE CASCADE;
