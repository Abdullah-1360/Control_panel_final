import { Injectable, Logger } from '@nestjs/common';
import { Client, ConnectConfig } from 'ssh2';
import * as crypto from 'crypto';
import * as dns from 'dns/promises';

export interface SSHConnectionConfig {
  host: string;
  port: number;
  username: string;
  privateKey?: string;
  passphrase?: string;
  password?: string;
  timeout?: number;
}

export interface ConnectionTestResult {
  success: boolean;
  message: string;
  latency: number;
  testedAt: Date;
  details: {
    dnsResolution: {
      success: boolean;
      ip?: string;
      time: number;
      error?: string;
    };
    tcpConnection: {
      success: boolean;
      time: number;
      error?: string;
    };
    hostKeyVerification: {
      success: boolean;
      keyType?: string;
      fingerprint?: string;
      fingerprintMD5?: string;
      matched?: boolean;
      error?: string;
    };
    authentication: {
      success: boolean;
      time: number;
      error?: string;
    };
    privilegeTest: {
      success: boolean;
      hasRoot?: boolean;
      hasSudo?: boolean;
      error?: string;
    };
    commandExecution: {
      whoami?: {
        success: boolean;
        output?: string;
        error?: string;
      };
      systemInfo?: {
        success: boolean;
        output?: string;
        error?: string;
      };
      customCommands?: Array<{
        command: string;
        success: boolean;
        output?: string;
        error?: string;
      }>;
    };
  };
  detectedOS?: string;
  detectedUsername?: string;
  errors: string[];
  warnings: string[];
}

interface PooledConnection {
  client: Client;
  serverId: string;
  lastUsed: Date;
  inUse: boolean;
}

@Injectable()
export class SSHConnectionService {
  private readonly logger = new Logger(SSHConnectionService.name);
  private readonly connectionPool: Map<string, PooledConnection[]> = new Map();
  private readonly maxPoolSize = 20;
  private readonly poolTimeout = 300000; // 5 minutes
  private readonly testTimeout = 25000; // 25 seconds per step

  /**
   * Dangerous command patterns that should be blocked
   */
  private readonly dangerousPatterns = [
    /rm\s+-rf\s+\/(?!tmp|var\/tmp)/i, // Prevent rm -rf / (except /tmp)
    /:\(\)\{.*\|.*&\s*\};:/i, // Fork bomb
    />\s*\/dev\/sd[a-z]/i, // Direct disk writes
    /dd\s+if=.*of=\/dev/i, // DD to devices
    /mkfs/i, // Format filesystem
    /fdisk/i, // Partition manipulation
    /shutdown|reboot|halt|poweroff/i, // System shutdown (unless explicitly allowed)
    /userdel|deluser/i, // User deletion
    /passwd.*root/i, // Root password change
    /chmod\s+777\s+\//i, // Dangerous permissions on root
    /curl.*\|\s*bash/i, // Piping to bash
    /wget.*\|\s*sh/i, // Piping to shell
  ];

  /**
   * Validate command for injection attempts and dangerous operations
   */
  private validateCommand(command: string): { valid: boolean; reason?: string } {
    // Check for null bytes (command injection)
    if (command.includes('\0')) {
      return { valid: false, reason: 'Null byte detected in command' };
    }

    // Allow multi-line commands (common for metrics collection)
    if (command.includes('\n')) {
      return { valid: true };
    }

    // Allow bash for loops (used for batch operations)
    if (/^for\s+\w+\s+in\s+.*;\s*do\s+.*;\s*done$/.test(command.trim())) {
      return { valid: true };
    }

    // Strip output redirections for validation (they're safe)
    // Remove: 2>/dev/null, 2>&1, >/dev/null, &>/dev/null, 1>&2, etc.
    const commandWithoutRedirects = command.replace(/\s+[12&]?>(?:&[12]|\/dev\/null)/g, '');

    // Check for dangerous command chaining
    // Allow safe patterns:
    // - cd /path && command (directory change)
    // - test/[ ... && echo (test conditions)
    // - || true/echo/return (safe fallbacks)
    // - command substitution in safe contexts (variable assignment)
    // - Pipes for safe commands (cat | grep, tail | grep, etc.)
    // Block:
    // - Dangerous && usage (command execution chaining)
    // - Dangerous || usage (command execution chaining)
    // - ; (command separator) except in for loops
    
    // Allow safe pipe patterns (read-only commands)
    const safePipePattern = /^(cat|tail|head|grep|awk|sed|sort|uniq|wc|ls|find|stat|df|du|ps|top|free|uptime|uname|whoami|id|date|echo)\s+.*\|/;
    const hasPipe = /\|/.test(commandWithoutRedirects);
    if (hasPipe && !safePipePattern.test(commandWithoutRedirects)) {
      return { valid: false, reason: 'Unsafe pipe usage detected' };
    }
    
    // Allow safe && patterns:
    // - cd /path && command
    // - test -f file && echo
    // - [ -f file ] && echo
    // - variable=$(...) && echo (command substitution in assignment)
    // - cd /path && wp command (WordPress CLI)
    // - cd /path && php command (PHP CLI)
    // - cd /path && any safe command
    const safeCdPattern = /^cd\s+[^\s;&|]+\s+&&\s+[a-zA-Z0-9_\-\.\/]+/;
    const safeTestPattern = /^(test\s+|\[\s+).*&&\s+(echo|true|return)/;
    const safeVarPattern = /^\w+=\$\([^)]+\)\s+&&\s+/;
    const hasUnsafeAnd = /&&/.test(commandWithoutRedirects) && 
                         !safeCdPattern.test(commandWithoutRedirects) && 
                         !safeTestPattern.test(commandWithoutRedirects) &&
                         !safeVarPattern.test(commandWithoutRedirects);
    
    // Allow safe fallback patterns:
    // - || true, || echo, || return (safe no-ops)
    // - command1 || command2 (where both are the same base command with different args - file path fallback)
    const safeFallbackPattern = /\|\|\s*(true|echo|return)/;
    const sameCommandFallback = /^(\w+(?:\s+-[a-zA-Z0-9]+)*)\s+[^\s;&|]+\s+\|\|\s+\1\s+/;
    const hasUnsafeOr = /\|\|/.test(commandWithoutRedirects) && 
                        !safeFallbackPattern.test(commandWithoutRedirects) && 
                        !sameCommandFallback.test(commandWithoutRedirects);
    
    // Allow semicolons in for loops, but block elsewhere
    const hasDangerousSemicolon = /;/.test(commandWithoutRedirects) && !/^for\s+\w+\s+in\s+.*;\s*do\s+.*;\s*done$/.test(commandWithoutRedirects.trim());
    
    if (hasUnsafeAnd || hasUnsafeOr || hasDangerousSemicolon) {
      return { valid: false, reason: 'Dangerous command chaining detected' };
    }

    // Allow command substitution in safe contexts (variable assignment, for loops)
    // Block dangerous command substitution (direct execution)
    if (/`/.test(command)) {
      return { valid: false, reason: 'Backtick command substitution detected' };
    }
    
    // Allow $(...) in variable assignments and for loops
    if (/\$\(/.test(command)) {
      const isInVarAssignment = /^\w+=\$\([^)]+\)/.test(command.trim());
      const isInForLoop = /^for\s+\w+\s+in\s+.*\$\(/.test(command.trim());
      const isInSafeContext = /\w+=\$\([^)]+\)/.test(command);
      
      if (!isInVarAssignment && !isInForLoop && !isInSafeContext) {
        return { valid: false, reason: 'Unsafe command substitution detected' };
      }
    }

    // Check for dangerous patterns
    for (const pattern of this.dangerousPatterns) {
      if (pattern.test(command)) {
        return { valid: false, reason: `Dangerous command pattern detected: ${pattern.source}` };
      }
    }

    return { valid: true };
  }

  /**
   * Test server connection with detailed diagnostics
   */
  async testConnection(
    config: SSHConnectionConfig,
    serverId: string,
    hostKeyStrategy: string,
    knownHostFingerprints: any[],
    sudoMode?: string,
    sudoPassword?: string,
    customCommands?: string[],
  ): Promise<ConnectionTestResult> {
    const startTime = Date.now();
    const result: ConnectionTestResult = {
      success: false,
      message: '',
      latency: 0,
      testedAt: new Date(),
      details: {
        dnsResolution: { success: false, time: 0 },
        tcpConnection: { success: false, time: 0 },
        hostKeyVerification: { success: false },
        authentication: { success: false, time: 0 },
        privilegeTest: { success: false },
        commandExecution: {},
      },
      errors: [],
      warnings: [],
    };

    try {
      // Step 1: DNS Resolution
      const dnsStart = Date.now();
      try {
        const addresses = await Promise.race([
          dns.resolve4(config.host),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('DNS timeout')), this.testTimeout),
          ),
        ]);
        result.details.dnsResolution = {
          success: true,
          ip: addresses[0],
          time: Date.now() - dnsStart,
        };
      } catch (error: any) {
        result.details.dnsResolution = {
          success: false,
          time: Date.now() - dnsStart,
          error: error.message,
        };
        result.errors.push(`DNS resolution failed: ${error.message}`);
        result.message = 'DNS resolution failed';
        result.latency = Date.now() - startTime;
        return result;
      }

      // Step 2-6: SSH Connection and Tests
      const sshResult = await this.performSSHTest(
        config,
        hostKeyStrategy,
        knownHostFingerprints,
        sudoMode,
        sudoPassword,
        customCommands,
      );

      // Merge SSH test results
      if (sshResult.details) {
        result.details.tcpConnection = sshResult.details.tcpConnection;
        result.details.hostKeyVerification = sshResult.details.hostKeyVerification;
        result.details.authentication = sshResult.details.authentication;
        result.details.privilegeTest = sshResult.details.privilegeTest;
        result.details.commandExecution = sshResult.details.commandExecution;
      }
      result.detectedOS = sshResult.detectedOS;
      result.detectedUsername = sshResult.detectedUsername;
      if (sshResult.errors) {
        result.errors.push(...sshResult.errors);
      }
      if (sshResult.warnings) {
        result.warnings.push(...sshResult.warnings);
      }

      result.success = sshResult.success || false;
      result.message = sshResult.success ? 'Connection test successful' : (sshResult.message || 'Connection test failed');
      result.latency = Date.now() - startTime;

      return result;
    } catch (error: any) {
      result.errors.push(`Unexpected error: ${error.message}`);
      result.message = 'Connection test failed';
      result.latency = Date.now() - startTime;
      return result;
    }
  }

  /**
   * Perform SSH connection and tests
   */
  private async performSSHTest(
    config: SSHConnectionConfig,
    hostKeyStrategy: string,
    knownHostFingerprints: any[],
    sudoMode?: string,
    sudoPassword?: string,
    customCommands?: string[],
  ): Promise<Partial<ConnectionTestResult>> {
    return new Promise((resolve) => {
      const result: Partial<ConnectionTestResult> = {
        success: false,
        message: '',
        details: {
          dnsResolution: { success: true, time: 0 },
          tcpConnection: { success: false, time: 0 },
          hostKeyVerification: { success: false },
          authentication: { success: false, time: 0 },
          privilegeTest: { success: false },
          commandExecution: {},
        },
        errors: [],
        warnings: [],
      };

      const client = new Client();
      const tcpStart = Date.now();
      let authStart = 0;

      const timeout = setTimeout(() => {
        client.end();
        result.errors!.push('Connection timeout (25 seconds)');
        result.message = 'Connection timeout';
        resolve(result);
      }, this.testTimeout);

      client.on('ready', async () => {
        result.details!.tcpConnection = {
          success: true,
          time: Date.now() - tcpStart,
        };

        result.details!.authentication = {
          success: true,
          time: Date.now() - authStart,
        };

        // Handle host key verification (simplified for now - will be enhanced later)
        result.details!.hostKeyVerification = {
          success: true,
          matched: true,
        };

        if (hostKeyStrategy === 'DISABLED') {
          result.warnings!.push('Host key verification disabled (security risk)');
        } else if (hostKeyStrategy === 'TOFU' && (!knownHostFingerprints || knownHostFingerprints.length === 0)) {
          result.warnings!.push('First connection - accepting host key (TOFU)');
        }

        try {
          // Test privilege escalation
          await this.testPrivileges(client, sudoMode, sudoPassword, result);

          // Execute test commands
          await this.executeTestCommands(client, customCommands, result);

          result.success = true;
          result.message = 'Connection successful';
        } catch (error: any) {
          result.errors!.push(`Command execution failed: ${error.message}`);
          result.message = 'Command execution failed';
        }

        client.end();
        clearTimeout(timeout);
        resolve(result);
      });

      client.on('error', (err: Error) => {
        clearTimeout(timeout);

        if (!result.details!.tcpConnection.success) {
          result.details!.tcpConnection = {
            success: false,
            time: Date.now() - tcpStart,
            error: err.message,
          };
          result.errors!.push(`TCP connection failed: ${err.message}`);
          result.message = 'TCP connection failed';
        } else if (!result.details!.authentication.success) {
          result.details!.authentication = {
            success: false,
            time: Date.now() - authStart,
            error: err.message,
          };
          result.errors!.push(`Authentication failed: ${err.message}`);
          result.message = 'Authentication failed';
        } else {
          result.errors!.push(`SSH error: ${err.message}`);
          result.message = 'SSH connection error';
        }

        resolve(result);
      });

      // Prepare SSH config
      authStart = Date.now();
      const sshConfig: ConnectConfig = {
        host: config.host,
        port: config.port,
        username: config.username,
        readyTimeout: this.testTimeout,
      };

      if (config.privateKey) {
        sshConfig.privateKey = config.privateKey;
        if (config.passphrase) {
          sshConfig.passphrase = config.passphrase;
        }
      } else if (config.password) {
        sshConfig.password = config.password;
      }

      client.connect(sshConfig);
    });
  }

  /**
   * Test privilege escalation
   */
  private async testPrivileges(
    client: Client,
    sudoMode?: string,
    sudoPassword?: string,
    result?: Partial<ConnectionTestResult>,
  ): Promise<void> {
    if (!sudoMode || sudoMode === 'NONE') {
      if (result) {
        result.details!.privilegeTest = {
          success: true,
          hasRoot: false,
          hasSudo: false,
        };
      }
      return;
    }

    return new Promise((resolve, reject) => {
      const command = sudoMode === 'NOPASSWD' ? 'sudo -n whoami' : 'sudo -S whoami';

      client.exec(command, (err, stream) => {
        if (err) {
          if (result) {
            result.details!.privilegeTest = {
              success: false,
              error: err.message,
            };
            result.warnings!.push(`Sudo test failed: ${err.message}`);
          }
          resolve();
          return;
        }

        let output = '';
        let errorOutput = '';

        if (sudoMode === 'PASSWORD_REQUIRED' && sudoPassword) {
          stream.stdin.write(`${sudoPassword}\n`);
        }

        stream.on('data', (data: Buffer) => {
          output += data.toString();
        });

        stream.stderr.on('data', (data: Buffer) => {
          errorOutput += data.toString();
        });

        stream.on('close', (code: number) => {
          if (result) {
            result.details!.privilegeTest = {
              success: code === 0,
              hasRoot: output.trim() === 'root',
              hasSudo: code === 0,
              error: code !== 0 ? errorOutput : undefined,
            };

            if (code !== 0) {
              result.warnings!.push('Sudo access not available or failed');
            }
          }
          resolve();
        });
      });
    });
  }

  /**
   * Execute test commands
   */
  private async executeTestCommands(
    client: Client,
    customCommands: string[] = [],
    result: Partial<ConnectionTestResult>,
  ): Promise<void> {
    // Default commands
    const whoamiResult = await this.executeCommandInternal(client, 'whoami');
    const unameResult = await this.executeCommandInternal(client, 'uname -a');

    result.details!.commandExecution = {
      whoami: whoamiResult,
      systemInfo: unameResult,
    };

    if (whoamiResult.success) {
      result.detectedUsername = whoamiResult.output?.trim();
    }

    if (unameResult.success) {
      result.detectedOS = unameResult.output?.trim();
    }

    // Custom commands
    if (customCommands && customCommands.length > 0) {
      result.details!.commandExecution.customCommands = [];
      for (const cmd of customCommands) {
        const cmdResult = await this.executeCommandInternal(client, cmd);
        result.details!.commandExecution.customCommands.push({
          command: cmd,
          ...cmdResult,
        });
      }
    }
  }

  /**
   * Execute a single command (private helper)
   */
  private async executeCommandInternal(
    client: Client,
    command: string,
  ): Promise<{ success: boolean; output?: string; error?: string }> {
    return new Promise((resolve) => {
      client.exec(command, (err, stream) => {
        if (err) {
          resolve({ success: false, error: err.message });
          return;
        }

        let output = '';
        let errorOutput = '';

        stream.on('data', (data: Buffer) => {
          output += data.toString();
        });

        stream.stderr.on('data', (data: Buffer) => {
          errorOutput += data.toString();
        });

        stream.on('close', (code: number) => {
          if (code === 0) {
            resolve({ success: true, output: this.sanitizeOutput(output) });
          } else {
            resolve({ success: false, error: errorOutput || 'Command failed' });
          }
        });
      });
    });
  }

  /**
   * Sanitize command output (remove sensitive data)
   */
  private sanitizeOutput(output: string): string {
    // Remove common sensitive patterns
    let sanitized = output;

    // Remove password patterns
    sanitized = sanitized.replace(/password[=:]\s*\S+/gi, 'password=***');

    // Remove SSH key patterns
    sanitized = sanitized.replace(
      /-----BEGIN .* KEY-----[\s\S]*?-----END .* KEY-----/g,
      '***SSH_KEY***',
    );

    // Remove token patterns
    sanitized = sanitized.replace(/token[=:]\s*\S+/gi, 'token=***');
    sanitized = sanitized.replace(/api[-_]?key[=:]\s*\S+/gi, 'api_key=***');

    // Remove environment variables that might contain secrets
    sanitized = sanitized.replace(/\b[A-Z_]+_SECRET[=:]\s*\S+/g, 'SECRET=***');
    sanitized = sanitized.replace(/\b[A-Z_]+_PASSWORD[=:]\s*\S+/g, 'PASSWORD=***');
    sanitized = sanitized.replace(/\b[A-Z_]+_KEY[=:]\s*\S+/g, 'KEY=***');

    return sanitized;
  }

  /**
   * Generate SSH key fingerprint
   */
  private generateFingerprint(key: Buffer, algorithm: 'sha256' | 'md5'): string {
    const hash = crypto.createHash(algorithm).update(key).digest();

    if (algorithm === 'sha256') {
      return `SHA256:${hash.toString('base64').replace(/=+$/, '')}`;
    } else {
      return `MD5:${hash.toString('hex').match(/.{2}/g)!.join(':')}`;
    }
  }

  /**
   * Get key type from SSH key
   */
  private getKeyType(key: Buffer): string {
    const keyStr = key.toString('base64');
    if (keyStr.startsWith('AAAAB3NzaC1yc2')) return 'ssh-rsa';
    if (keyStr.startsWith('AAAAC3NzaC1lZDI1NTE5')) return 'ssh-ed25519';
    if (keyStr.startsWith('AAAAE2VjZHNhLXNoYTItbmlzdHA')) return 'ecdsa-sha2-nistp256';
    return 'unknown';
  }

  /**
   * Get connection from pool or create new one
   */
  async getConnection(serverId: string, config: SSHConnectionConfig): Promise<Client> {
    // Check if there's an available connection in the pool
    const pool = this.connectionPool.get(serverId) || [];
    const available = pool.find((conn) => !conn.inUse);

    if (available) {
      available.inUse = true;
      available.lastUsed = new Date();
      return available.client;
    }

    // Create new connection if pool not full
    if (pool.length < this.maxPoolSize) {
      const client = await this.createConnection(config);
      const pooled: PooledConnection = {
        client,
        serverId,
        lastUsed: new Date(),
        inUse: true,
      };

      pool.push(pooled);
      this.connectionPool.set(serverId, pool);

      return client;
    }

    // Pool is full, wait or create temporary connection
    throw new Error('Connection pool exhausted');
  }

  /**
   * Create a new SSH connection
   */
  private async createConnection(config: SSHConnectionConfig): Promise<Client> {
    return new Promise((resolve, reject) => {
      const client = new Client();

      client.on('ready', () => {
        resolve(client);
      });

      client.on('error', (err) => {
        reject(err);
      });

      const sshConfig: ConnectConfig = {
        host: config.host,
        port: config.port,
        username: config.username,
        readyTimeout: this.testTimeout,
      };

      if (config.privateKey) {
        sshConfig.privateKey = config.privateKey;
        if (config.passphrase) {
          sshConfig.passphrase = config.passphrase;
        }
      } else if (config.password) {
        sshConfig.password = config.password;
      }

      client.connect(sshConfig);
    });
  }

  /**
   * Release connection back to pool
   */
  releaseConnection(serverId: string, client: Client): void {
    const pool = this.connectionPool.get(serverId);
    if (!pool) return;

    const conn = pool.find((c) => c.client === client);
    if (conn) {
      conn.inUse = false;
      conn.lastUsed = new Date();
    }
  }

  /**
   * Clean up old connections from pool
   */
  async cleanupPool(): Promise<void> {
    const now = new Date();

    for (const [serverId, pool] of this.connectionPool.entries()) {
      const toRemove: PooledConnection[] = [];

      for (const conn of pool) {
        if (!conn.inUse && now.getTime() - conn.lastUsed.getTime() > this.poolTimeout) {
          conn.client.end();
          toRemove.push(conn);
        }
      }

      // Remove old connections
      const remaining = pool.filter((c) => !toRemove.includes(c));
      if (remaining.length === 0) {
        this.connectionPool.delete(serverId);
      } else {
        this.connectionPool.set(serverId, remaining);
      }
    }
  }

  /**
   * Execute a command on a server (public method for metrics collection)
   */
  async executeCommand(
    config: SSHConnectionConfig,
    serverId: string,
    command: string,
  ): Promise<{ success: boolean; output?: string; error?: string }> {
    // Validate command for injection attempts
    const validation = this.validateCommand(command);
    if (!validation.valid) {
      this.logger.warn(`Command validation failed for server ${serverId}: ${validation.reason}`);
      return {
        success: false,
        error: `Command rejected: ${validation.reason}`,
      };
    }

    const client = new Client();

    return new Promise((resolve) => {
      const sshConfig: ConnectConfig = {
        host: config.host,
        port: config.port,
        username: config.username,
        readyTimeout: config.timeout || 30000,
      };

      // Add authentication method
      if (config.privateKey) {
        sshConfig.privateKey = config.privateKey;
        if (config.passphrase) {
          sshConfig.passphrase = config.passphrase;
        }
      } else if (config.password) {
        sshConfig.password = config.password;
      }

      client.on('ready', () => {
        client.exec(command, (err, stream) => {
          if (err) {
            client.end();
            resolve({ success: false, error: err.message });
            return;
          }

          let output = '';
          let errorOutput = '';

          stream.on('data', (data: Buffer) => {
            output += data.toString();
          });

          stream.stderr.on('data', (data: Buffer) => {
            errorOutput += data.toString();
          });

          stream.on('close', (code: number) => {
            client.end();
            if (code === 0) {
              resolve({ success: true, output: this.sanitizeOutput(output) });
            } else {
              resolve({ success: false, error: errorOutput || 'Command failed' });
            }
          });
        });
      });

      client.on('error', (err) => {
        resolve({ success: false, error: err.message });
      });

      client.connect(sshConfig);
    });
  }
}

