import { Injectable, Logger } from '@nestjs/common';
import { ServersService } from '../../servers/servers.service';
import { SSHConnectionService } from '../../servers/ssh-connection.service';

/**
 * SSH Executor Service for Healer Module
 * Executes SSH commands on servers using Module 2's SSH infrastructure
 */
@Injectable()
export class SshExecutorService {
  private readonly logger = new Logger(SshExecutorService.name);

  constructor(
    private readonly serversService: ServersService,
    private readonly sshConnection: SSHConnectionService,
  ) {}

  /**
   * Execute a command on a server via SSH
   * @param serverId Server ID
   * @param command Command to execute
   * @returns Command output as string
   */
  async executeCommand(serverId: string, command: string): Promise<string> {
    try {
      // Get server configuration with decrypted credentials
      const serverConfig = await this.serversService.getServerForConnection(serverId);

      // Prepare SSH config
      const sshConfig = {
        host: serverConfig.host,
        port: serverConfig.port,
        username: serverConfig.username,
        privateKey: serverConfig.credentials.privateKey,
        passphrase: serverConfig.credentials.passphrase,
        password: serverConfig.credentials.password,
        timeout: 30000, // 30 second timeout
      };

      // Execute command
      const result = await this.sshConnection.executeCommand(
        sshConfig,
        serverId,
        command,
      );

      if (!result.success) {
        this.logger.error(
          `SSH command failed on server ${serverId}: ${result.error}`,
        );
        throw new Error(result.error || 'SSH command execution failed');
      }

      return result.output || '';
    } catch (error) {
      const err = error as Error;
      this.logger.error(
        `Failed to execute SSH command on server ${serverId}: ${err.message}`,
      );
      throw error;
    }
  }
}
