import { IsString, IsUUID } from 'class-validator';

export class HealSiteDto {
  @IsString()
  @IsUUID()
  executionId!: string;
}
