import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { HealerController } from './healer.controller';
import { HealerService } from './healer.service';
import { SiteDiscoveryService } from './services/site-discovery.service';
import { LogAnalysisService } from './services/log-analysis.service';
import { DiagnosisService } from './services/diagnosis.service';
import { HealingOrchestratorService } from './services/healing-orchestrator.service';
import { BackupService } from './services/backup.service';
import { WpCliService } from './services/wp-cli.service';
import { SshExecutorService } from './services/ssh-executor.service';
import { PatternLearningService } from './services/pattern-learning.service';
import { ManualDiagnosisService } from './services/manual-diagnosis.service';
import { HealingProcessor } from './processors/healing.processor';
import { WsodHealerRunbook } from './runbooks/wsod-healer.runbook';
import { MaintenanceHealerRunbook } from './runbooks/maintenance-healer.runbook';
import { PrismaService } from './stubs/prisma.service.stub';
import { ServersModule } from '../servers/servers.module';

@Module({
  imports: [
    ServersModule, // Import Module 2 for SSH functionality
    BullModule.registerQueue({
      name: 'healer-jobs',
    }),
  ],
  controllers: [HealerController],
  providers: [
    // Stub services (TODO: Remove when actual modules are integrated)
    PrismaService,
    // Healer services
    HealerService,
    SiteDiscoveryService,
    LogAnalysisService,
    DiagnosisService,
    HealingOrchestratorService,
    BackupService,
    WpCliService,
    SshExecutorService, // Real SSH executor using Module 2
    PatternLearningService, // Self-learning automation
    ManualDiagnosisService, // Manual diagnosis with learning
    HealingProcessor,
    WsodHealerRunbook,
    MaintenanceHealerRunbook,
  ],
  exports: [HealerService],
})
export class HealerModule {}
