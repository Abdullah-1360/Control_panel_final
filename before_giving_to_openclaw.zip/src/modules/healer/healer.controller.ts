import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { HealerService } from './healer.service';
import { PatternLearningService } from './services/pattern-learning.service';
import { ManualDiagnosisService } from './services/manual-diagnosis.service';
// TODO: Import these from Module 1 when available
// import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
// import { PermissionsGuard } from '../auth/guards/permissions.guard';
// import { Permissions } from '../auth/decorators/permissions.decorator';
// import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { DiscoverSitesDto } from './dto/discover-sites.dto';
import { HealSiteDto } from './dto/heal-site.dto';
import { UpdateSiteConfigDto } from './dto/update-site-config.dto';

@Controller('healer')
// @UseGuards(JwtAuthGuard, PermissionsGuard) // TODO: Enable when Module 1 is integrated
export class HealerController {
  constructor(
    private readonly healerService: HealerService,
    private readonly patternLearning: PatternLearningService,
    private readonly manualDiagnosis: ManualDiagnosisService,
  ) {}

  /**
   * POST /api/v1/healer/discover
   * Discover WordPress sites on a server
   */
  @Post('discover')
  // @Permissions('healer.discover') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async discoverSites(@Body() dto: DiscoverSitesDto) {
    const result = await this.healerService.discoverSites(dto.serverId);
    return { data: result };
  }

  /**
   * GET /api/v1/healer/sites
   * List all sites with filtering
   */
  @Get('sites')
  // @Permissions('healer.read') // TODO: Enable when Module 1 is integrated
  async listSites(
    @Query('serverId') serverId?: string,
    @Query('healthStatus') healthStatus?: string,
    @Query('isHealerEnabled') isHealerEnabled?: string,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const filters = {
      serverId,
      healthStatus,
      isHealerEnabled: isHealerEnabled === 'true' ? true : undefined,
      search,
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 50,
    };

    return this.healerService.listSites(filters);
  }

  /**
   * GET /api/v1/healer/sites/:id
   * Get site details
   */
  @Get('sites/:id')
  // @Permissions('healer.read') // TODO: Enable when Module 1 is integrated
  async getSite(@Param('id') siteId: string) {
    const site = await this.healerService.getSite(siteId);
    return { data: site };
  }

  /**
   * GET /api/v1/healer/search
   * Fuzzy search sites by domain
   */
  @Get('search')
  // @Permissions('healer.read') // TODO: Enable when Module 1 is integrated
  async searchSites(@Query('q') query: string) {
    const results = await this.healerService.searchSites(query);
    return { data: results };
  }

  /**
   * POST /api/v1/healer/sites/:id/diagnose
   * Trigger diagnosis for a site
   */
  @Post('sites/:id/diagnose')
  // @Permissions('healer.diagnose') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async diagnose(
    @Param('id') siteId: string,
    // @CurrentUser() user: any, // TODO: Enable when Module 1 is integrated
  ) {
    const result = await this.healerService.diagnose(siteId, 'system'); // TODO: Use user.id when available
    return { data: result };
  }

  /**
   * POST /api/v1/healer/sites/:id/heal
   * Execute healing (manual button click)
   */
  @Post('sites/:id/heal')
  // @Permissions('healer.heal') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async heal(
    @Param('id') siteId: string,
    @Body() dto: HealSiteDto,
  ) {
    const result = await this.healerService.heal(dto.executionId);
    return { data: result };
  }

  /**
   * POST /api/v1/healer/sites/:id/rollback/:executionId
   * Rollback to backup
   */
  @Post('sites/:id/rollback/:executionId')
  // @Permissions('healer.rollback') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async rollback(
    @Param('id') siteId: string,
    @Param('executionId') executionId: string,
  ) {
    await this.healerService.rollback(executionId);
    return {
      data: {
        message: 'Rollback completed successfully',
        executionId,
      },
    };
  }

  /**
   * GET /api/v1/healer/sites/:id/executions
   * Get healing history for a site
   */
  @Get('sites/:id/executions')
  // @Permissions('healer.read') // TODO: Enable when Module 1 is integrated
  async getHealingHistory(
    @Param('id') siteId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.healerService.getHealingHistory(
      siteId,
      page ? parseInt(page) : 1,
      limit ? parseInt(limit) : 20,
    );
  }

  /**
   * GET /api/v1/healer/executions/:id
   * Get execution details with logs
   */
  @Get('executions/:id')
  // @Permissions('healer.read') // TODO: Enable when Module 1 is integrated
  async getExecution(@Param('id') executionId: string) {
    const execution = await this.healerService.getExecution(executionId);
    return { data: execution };
  }

  /**
   * PATCH /api/v1/healer/sites/:id/config
   * Update site healer configuration
   */
  @Patch('sites/:id/config')
  // @Permissions('healer.configure') // TODO: Enable when Module 1 is integrated
  async updateSiteConfig(
    @Param('id') siteId: string,
    @Body() config: UpdateSiteConfigDto,
  ) {
    const site = await this.healerService.updateSiteConfig(siteId, config);
    return { data: site };
  }

  /**
   * GET /api/v1/healer/patterns
   * List all learned healing patterns
   */
  @Get('patterns')
  // @Permissions('healer.read') // TODO: Enable when Module 1 is integrated
  async listPatterns(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.patternLearning.getAllPatterns(
      page ? parseInt(page) : 1,
      limit ? parseInt(limit) : 50,
    );
  }

  /**
   * DELETE /api/v1/healer/patterns/:id
   * Delete a learned pattern
   */
  @Delete('patterns/:id')
  // @Permissions('healer.admin') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.NO_CONTENT)
  async deletePattern(@Param('id') patternId: string) {
    await this.patternLearning.deletePattern(patternId);
  }

  /**
   * PATCH /api/v1/healer/patterns/:id/approval
   * Manually approve or disapprove a pattern
   */
  @Patch('patterns/:id/approval')
  // @Permissions('healer.admin') // TODO: Enable when Module 1 is integrated
  async setPatternApproval(
    @Param('id') patternId: string,
    @Body() body: { approved: boolean },
  ) {
    await this.patternLearning.setPatternApproval(patternId, body.approved);
    return {
      data: {
        message: `Pattern ${body.approved ? 'approved' : 'disapproved'} successfully`,
        patternId,
      },
    };
  }

  /**
   * POST /api/v1/healer/sites/:id/diagnose/manual
   * Start manual diagnosis session
   */
  @Post('sites/:id/diagnose/manual')
  // @Permissions('healer.diagnose') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async startManualDiagnosis(
    @Param('id') siteId: string,
    // @CurrentUser() user: any, // TODO: Enable when Module 1 is integrated
  ) {
    const result = await this.manualDiagnosis.startManualDiagnosis(siteId, 'system'); // TODO: Use user.id
    return { data: result };
  }

  /**
   * POST /api/v1/healer/manual/:sessionId/execute
   * Execute command in manual diagnosis session
   */
  @Post('manual/:sessionId/execute')
  // @Permissions('healer.diagnose') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async executeManualCommand(
    @Param('sessionId') sessionId: string,
    @Body() body: { command: string },
  ) {
    const result = await this.manualDiagnosis.executeCommand(sessionId, body.command);
    return { data: result };
  }

  /**
   * POST /api/v1/healer/manual/:sessionId/suggest
   * Get next command suggestions
   */
  @Post('manual/:sessionId/suggest')
  // @Permissions('healer.diagnose') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async suggestNextCommand(
    @Param('sessionId') sessionId: string,
    @Body() body: { lastCommand: string; lastOutput: string },
  ) {
    const suggestions = await this.manualDiagnosis.suggestNextCommand(
      sessionId,
      body.lastCommand,
      body.lastOutput,
    );
    return { data: suggestions };
  }

  /**
   * POST /api/v1/healer/manual/:sessionId/auto
   * Switch to auto mode
   */
  @Post('manual/:sessionId/auto')
  // @Permissions('healer.diagnose') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async switchToAutoMode(@Param('sessionId') sessionId: string) {
    const result = await this.manualDiagnosis.switchToAutoMode(sessionId);
    return { data: result };
  }

  /**
   * POST /api/v1/healer/manual/:sessionId/complete
   * Complete manual diagnosis
   */
  @Post('manual/:sessionId/complete')
  // @Permissions('healer.diagnose') // TODO: Enable when Module 1 is integrated
  @HttpCode(HttpStatus.OK)
  async completeManualDiagnosis(
    @Param('sessionId') sessionId: string,
    @Body() body: { findings: any },
  ) {
    const result = await this.manualDiagnosis.completeManualDiagnosis(sessionId, body.findings);
    return { data: result };
  }

  /**
   * GET /api/v1/healer/manual/:sessionId
   * Get manual diagnosis session details
   */
  @Get('manual/:sessionId')
  // @Permissions('healer.read') // TODO: Enable when Module 1 is integrated
  async getManualSession(@Param('sessionId') sessionId: string) {
    const session = await this.manualDiagnosis.getSession(sessionId);
    return { data: session };
  }
}
