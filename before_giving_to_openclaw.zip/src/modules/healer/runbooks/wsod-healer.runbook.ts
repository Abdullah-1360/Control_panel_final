import { Injectable, Logger } from '@nestjs/common';
import { WpCliService } from '../services/wp-cli.service';
import { SshExecutorService } from '../services/ssh-executor.service';

interface HealingContext {
  site: any;
  execution: any;
  diagnosisDetails: any;
}

interface HealingResult {
  success: boolean;
  action: string;
  details: any;
}

@Injectable()
export class WsodHealerRunbook {
  private readonly logger = new Logger(WsodHealerRunbook.name);

  constructor(
    private readonly wpCliService: WpCliService,
    private readonly sshService: SshExecutorService,
  ) {}

  /**
   * Execute WSOD healing
   */
  async execute(context: HealingContext): Promise<HealingResult> {
    const { site, diagnosisDetails } = context;

    this.logger.log(`Executing WSOD healer for site ${site.domain}`);

    try {
      const errorType = diagnosisDetails.errorType;

      if (errorType === 'PLUGIN_FAULT') {
        return await this.healPluginFault(site, diagnosisDetails);
      } else if (errorType === 'THEME_FAULT') {
        return await this.healThemeFault(site, diagnosisDetails);
      } else {
        // Unknown WSOD cause - activate safe mode
        return await this.activateSafeMode(site);
      }
    } catch (error) {
      const err = error as Error;
      this.logger.error(`WSOD healing failed: ${err.message}`, err.stack);
      throw error;
    }
  }

  /**
   * Heal plugin fault by deactivating faulty plugin
   */
  private async healPluginFault(
    site: any,
    diagnosisDetails: any,
  ): Promise<HealingResult> {
    const culprit = diagnosisDetails.culprit;

    this.logger.log(`Deactivating faulty plugin: ${culprit}`);

    // Check if plugin is blacklisted
    if (this.isBlacklisted(culprit, site.blacklistedPlugins)) {
      throw new Error(
        `Plugin ${culprit} is blacklisted and cannot be deactivated`,
      );
    }

    // Deactivate plugin
    await this.wpCliService.execute(
      site.serverId,
      site.path,
      `plugin deactivate ${culprit}`,
    );

    return {
      success: true,
      action: `Deactivated faulty plugin: ${culprit}`,
      details: { plugin: culprit },
    };
  }

  /**
   * Heal theme fault by switching to default theme
   */
  private async healThemeFault(
    site: any,
    diagnosisDetails: any,
  ): Promise<HealingResult> {
    const culprit = diagnosisDetails.culprit;

    this.logger.log(`Switching from faulty theme: ${culprit}`);

    // Check if theme is blacklisted
    if (this.isBlacklisted(culprit, site.blacklistedThemes)) {
      throw new Error(
        `Theme ${culprit} is blacklisted and cannot be switched`,
      );
    }

    // Switch to default theme
    await this.wpCliService.execute(
      site.serverId,
      site.path,
      'theme activate twentytwentyfour',
    );

    return {
      success: true,
      action: 'Switched to default theme: twentytwentyfour',
      details: { oldTheme: culprit, newTheme: 'twentytwentyfour' },
    };
  }

  /**
   * Activate safe mode (deactivate all plugins)
   */
  private async activateSafeMode(site: any): Promise<HealingResult> {
    this.logger.log('Activating safe mode - deactivating all plugins');

    // Deactivate all plugins
    await this.wpCliService.execute(
      site.serverId,
      site.path,
      'plugin deactivate --all',
    );

    return {
      success: true,
      action: 'Activated safe mode: deactivated all plugins',
      details: { mode: 'safe' },
    };
  }

  /**
   * Verify healing success
   */
  async verify(context: HealingContext): Promise<boolean> {
    const { site } = context;

    this.logger.log(`Verifying WSOD healing for site ${site.domain}`);

    try {
      // Check if site returns HTTP 200
      // For now, return true (implement actual HTTP check)
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Check if plugin/theme is blacklisted
   */
  private isBlacklisted(name: string, blacklist: string[]): boolean {
    if (!blacklist || blacklist.length === 0) {
      return false;
    }

    // Check exact match
    if (blacklist.includes(name)) {
      return true;
    }

    // Check wildcard match (e.g., woocommerce-*)
    for (const pattern of blacklist) {
      if (pattern.endsWith('*')) {
        const prefix = pattern.slice(0, -1);
        if (name.startsWith(prefix)) {
          return true;
        }
      }
    }

    return false;
  }
}
